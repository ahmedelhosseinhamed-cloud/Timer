// Creates server/.env with a random JWT_SECRET if it does not exist yet. Works on Windows, macOS and Linux.
import { randomBytes } from 'node:crypto'
import { copyFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs'

const example = new URL('../server/.env.example', import.meta.url)
const target = new URL('../server/.env', import.meta.url)

if (existsSync(target)) {
  console.log('server/.env already exists, leaving it unchanged.')
} else {
  copyFileSync(example, target)
  const secret = randomBytes(48).toString('hex')
  writeFileSync(target, readFileSync(target, 'utf8').replace('change-me-to-a-long-random-string', secret))
  console.log('Created server/.env with a new random JWT_SECRET.')
}
